#ifndef ___TEXTURE___
#define ___TEXTURE___

struct TextureID{
	unsigned ID;
	unsigned height;
	unsigned width;
};
#endif