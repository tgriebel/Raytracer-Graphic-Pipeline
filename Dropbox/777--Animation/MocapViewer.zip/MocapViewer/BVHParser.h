#include <vector>
#include <string.h>
#include "MVector.h"

using namespace std;

//struct MOCAPSEGMENT 
//{ 
//	 char *name; // Name of motion capture file 
//	 NODE* root; // Pointer to the root node of the animation 
//	 MOCAPHEADER* header; // Pointer to a structure that containers global parameters 
//	 NODE** nodelist; // Array of pointers to skeletal nodes 
//}; 
//
//struct MOCAPHEADER 
//{ 
//	 // Assumes that all angles are in degrees if not then they need to be converted 
//	 int noofsegments; // Number of body segments 
//	 long noofframes; // Number of frames 
//	 int datarate; // Number of frames per second 
//	 int euler[3][3]; // Specifies how the euler angle is defined 
//	 double callib; // Scale factor for converting current translation units into meters
//	 bool degrees; // Are the rotational measurements in degrees 
//	 double scalefactor; // Global Scale factor 
//	 long currentframe; // Stores the current frame to render 
//	 double floor; // Specifies position of the floor along the y-axis 
//}; 
//

struct abstract_node{

public:
	virtual ~abstract_node() = 0;

	unsigned num_children; // Number of child nodes
	abstract_node* parent; // Back pointer to parent node
	abstract_node** children; // Array of pointers to child nodes 

	unsigned DOF;
	string name;
	string channels;
};

struct RootNode: abstract_node{

	vec3d rootPointX;
	vec3d rootPointY;
	vec3d rootPointZ;
};

struct NODE_TRANSFORM{

	vec3d transZ; // Rotation of base position 
	vec3d transX; 
	vec3d transY;

	vec3d rotationsZ; // Rotation of base position 
	vec3d rotationsX; 
	vec3d rotationsY; 
};

struct NODE // Start of structure representing a single bone in a skeleton 
{  
	 char *name; 
	 double length; // Length of segment along the Y-Axis 
	 double offset[3]; // Transitional offset with respect to the end of the parent link 
	 double endPoint[3];
	 double* rootPointX;
	 double* rootPointY;
	 double* rootPointZ;
	 double* rotationsZ; // Rotation of base position 
	 double* rotationsX; 
	 double* rotationsY; 
	 double frameRate;
	 int noofFrames;
	 int noofchildren; // Number of child nodes 
	 NODE **children; // Array of pointers to child nodes 
	 NODE *parent; // Back pointer to parent node
	 int DOF; 
	 string* channels;
	 //double** history;
	 vec3d* history;

	double pos[3];

	 vec3d X;
	 vec3d Y;
	 vec3d Z;

	 NODE(): X(1.f, 0.f, 0.f),
			 Y(0.f, 1.f, 0.f),
			 Z(0.f, 0.f, 1.f){}
	
}; 

class BVHParser 
{
	public:
		BVHParser();
		NODE* getFigure(const char *filename);
		vector<double> getMotions(const char *filename);
		bool ExportData(const char *filename);
		~BVHParser();

		time_t current_time;
		int startTime;

	private:
		int xpos, ypos, zpos;
		string getName( const string& s);
		void getChannels( const string& s, vector<string>&);
		double* getOffset( const string& s);
		void addChild(NODE* parent, NODE* currentNode);

		double getFrames( const string& s);
		double getFrameTime( const string& s);
		void addMotions(const string& s, vector<double>& motions);
		void getMotions(const string& s, vector<string>& stringData);
		int addRotation(NODE* n, vector<string>& rotations, int index, int frame);
		void addRotation(NODE* n, ifstream& file, int frame);
		void initializeDOF(NODE* n, int frames);
		void initializeHistory(NODE* n, int frames);

		/*
		void IncreaseChildren(NODE* node);
		void RotateSegment(double &x, double &y, double &z, NODE* tnode);
		void ReCalcRotations(NODE* curnode);
		*/
};