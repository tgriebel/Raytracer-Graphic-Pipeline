#include <iostream>
#include <time.h>
#include <sstream>
#include <cstring>
#include <cctype>
using namespace std;

#include <gl\glut.h>

#include <iostream>
using namespace std;

#include <gl\glut.h>
#include <vector>

#define ESC 0x1B

#include "texture.h"
//#include "animation.h"
#include "UI.h"
#include "global.h"
#include "FreeCamera.h"
#include "BVHParser.h"
#include "Node.h"
#include "Quaternion.h"

bool quit = false;

void myInit();
#include "menu.h"

unsigned gW, gH;
unsigned TIMER_MS = 25;// 25 milliseconds makes the display update every 24 times/second
unsigned passed_time = 0;
const unsigned draw_dist = 40;

vector<NODE> motionSets;
BVHParser parser;
NODE* figure;

vector<vec2d> splices;

int frame = 0;
int fps = 0;
int motionIndex = 0;

vec3d lastKnownRootPos;
//vector<double> motionData = parser.getMotions("Example1.bvh");

UI *ui;

FreeCamera* camera;//use reference to change between free cam and target cam easily

bool cullback = true;
bool FREECAM_MODE = false;
bool LEFTMOUSE_DOWN = false;
bool ORBIT_MODE = false;
bool wireframe_flag = false;
bool play = false;
bool prevDown = false;
bool nextDown = false;

TextureID checkerTex;

void specialKeys(int key, int x, int y);
void myKeyboard(unsigned char key, int x, int y);
void update(int value);
void mouseAim(int x2, int y2);
void mouse(int btn, int state, int x, int y);
void computePos(NODE* n, double p[]);

void toggleFreeCamMode(){
	FREECAM_MODE ^= true;
	ORBIT_MODE = false;
}

void toggleOrbitCamMode(){
	ORBIT_MODE ^= true;
	FREECAM_MODE = false;
}

void togglePlay(){
	play ^= true;
}

void nextFrame(){
	nextDown = true;
	if(frame < (figure->noofFrames) - 1){
		frame++;
	}else{
		frame = 0;
	}
}

void prevFrame(){
	prevDown = true;
	if(frame > 0 ){
		frame--;
	}
}


void display(){}
void clearWindow(){
	glClearColor(0.0, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

void PerspectiveSet(int w, int h, double fov){
	glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
	glViewport(0, 78, w, h);
	gluPerspective(fov,(w/(h*1.0)),.01,draw_dist);
    
    glMatrixMode(GL_MODELVIEW);
}
void OrthoSet(int w, int h){}
void myReshape(int w, int h)
{

	gW = w;
	gH = h;

	PerspectiveSet(w, h, camera->fov);

	ui->resize(gW, gH);

}

void drawCube(double x, double y, double z, double size){

	float color[4] = {1.0,0.0,0.0,0.5};
	glColor4fv(color);

	glNormal3f(1.0,0.0,0.0);
	glBegin(GL_QUADS);
		glVertex3f(x+size, y+size, z);
		glVertex3f(x+size, y+size, z+size);
		glVertex3f(x+size, y, z+size);
		glVertex3f(x+size,y,z);	
	glEnd();

	glNormal3f(-1.0,0.0,0.0);
	glBegin(GL_QUADS);
		glVertex3f(x, y, z+size);
		glVertex3f(x, y+size, z+size);
		glVertex3f(x, y+size, z);
		glVertex3f(x,y,z);
	glEnd();

	glNormal3f(0.0,0.0,-1.0);
	glBegin(GL_QUADS);
		glVertex3f(x+size, y, z+size);
		glVertex3f(x+size, y+size, z+size);
		glVertex3f(x, y+size, z+size);
		glVertex3f(x,y,z+size);	
	glEnd();
	
	glNormal3f(0.0,0.0,1.0);
	glBegin(GL_QUADS);
		glVertex3f(x, y+size, z);
		glVertex3f(x+size, y+size, z);
		glVertex3f(x+size, y, z);
		glVertex3f(x,y,z);
	glEnd();

	glNormal3f(0.0,-1.0,0.0);
	glBegin(GL_QUADS);
		glVertex3f(x, y+size, z);
		glVertex3f(x+size, y+size, z);
		glVertex3f(x+size, y+size, z+size);
		glVertex3f(x,y+size,z+size);
	glEnd();

	glNormal3f(0.0,1.0,0.0);
	glBegin(GL_QUADS);
		glVertex3f(x, y, z);
		glVertex3f(x+size, y, z);
		glVertex3f(x+size, y, z+size);
		glVertex3f(x,y,z+size);
	glEnd();

}

void myInit()
{
	const string aniName1 = "03_01.bvh";
	//const string aniName1 = "Example1.bvh";
	//const string aniName2 = "02_03.bvh";
	const string aniName2 = "03_01.bvh";
	cout<<"Loading Figure 1..."<<endl;
	NODE* figure1 = parser.getFigure(aniName1.c_str()); 
	cout<<"Loading Figure 2..."<<endl;
	NODE* figure2 = parser.getFigure(aniName2.c_str()); 
	cout<<"Loading Complete"<<endl;

	motionSets.push_back(*figure1);
	motionSets.push_back(*figure2);

	//splices.push_back(vec2d(0,figure1->noofFrames));
	splices.push_back(vec2d(5,100));
	splices.push_back(vec2d(0,figure2->noofFrames));

	//figure = &motionSets.front();
	figure = &motionSets[motionIndex];

	frame = splices[motionIndex][0]; 

	cullback = true;
	FREECAM_MODE = false;
	wireframe_flag = false;
	quit = false;

	glClearColor(1.0, .5, .5, 1.0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glutDisplayFunc(display);
	glutKeyboardFunc(myKeyboard);
	glutSpecialFunc(specialKeys);
	glutReshapeFunc(myReshape);
	glutMouseFunc(mouse);
	glutPassiveMotionFunc(mouseAim);

	//glEnable(GL_CULL_FACE);
	glEnable(GL_DEPTH_TEST);
	glDepthMask(true);

	TextureID textID;
	loadTexture32("UI.bmp", textID);

	ui = new UI(gH, gW, textID);

	loadTexture32("cam_but.bmp", textID);
	ui->buttons[0].frames[0] = textID;
	loadTexture32("cam_but_down.bmp", textID);
	ui->buttons[0].frames[1] = textID;
	ui->buttons[0].x = 8;
	ui->buttons[0].y = 8;
	ui->buttons[0].h = 64;
	ui->buttons[0].w = 64;
	ui->buttons[0].frame = 0;
	ui->buttons[0].click = toggleFreeCamMode;
	ui->buttons[0].global_control = &FREECAM_MODE;
	ui->numButs++;
	
	loadTexture32("orbit_but.bmp", textID);
	ui->buttons[1].frames[0] = textID;
	loadTexture32("orbit_but_down.bmp", textID);
	ui->buttons[1].frames[1] = textID;
	ui->buttons[1].x = 76;
	ui->buttons[1].y = 8;
	ui->buttons[1].h = 64;
	ui->buttons[1].w = 64;
	ui->buttons[1].frame = 0;
	ui->buttons[1].click = toggleOrbitCamMode;
	ui->buttons[1].global_control = &ORBIT_MODE;
	ui->numButs++;
	
	loadTexture32("prev_but.bmp", textID);
	ui->buttons[2].frames[0] = textID;
	loadTexture32("prev_but_down.bmp", textID);
	ui->buttons[2].frames[1] = textID;
	ui->buttons[2].x = 424;
	ui->buttons[2].y = 8;
	ui->buttons[2].h = 64;
	ui->buttons[2].w = 64;
	ui->buttons[2].frame = 0;
	ui->buttons[2].click = prevFrame;
	ui->buttons[2].global_control = &prevDown;
	ui->numButs++;

	loadTexture32("next_but.bmp", textID);
	ui->buttons[3].frames[0] = textID;
	loadTexture32("next_but_down.bmp", textID);
	ui->buttons[3].frames[1] = textID;
	ui->buttons[3].x = 492;
	ui->buttons[3].y = 8;
	ui->buttons[3].h = 64;
	ui->buttons[3].w = 64;
	ui->buttons[3].frame = 0;
	ui->buttons[3].click = nextFrame;
	ui->buttons[3].global_control = &nextDown;
	ui->numButs++;

	loadTexture32("play_but.bmp", textID);
	ui->buttons[4].frames[0] = textID;
	loadTexture32("pause_but.bmp", textID);
	ui->buttons[4].frames[1] = textID;
	ui->buttons[4].x = 560;
	ui->buttons[4].y = 8;
	ui->buttons[4].h = 64;
	ui->buttons[4].w = 64;
	ui->buttons[4].frame = 0;
	ui->buttons[4].click = togglePlay;
	ui->buttons[4].global_control = &play;
	ui->numButs++;
	
	loadTexture32("checker.bmp", checkerTex);

	camera = new FreeCamera(0.5, 0.75, 0.5);
	
	glutTimerFunc(TIMER_MS, update, 0);
	glutPostRedisplay();

	ui->totalFrames = &(figure->noofFrames);
	ui->currentFrame = &frame;
	ui->fps = &fps;

	fps = 1.0f/figure->frameRate;
	TIMER_MS = 1000 / fps;
}

void mouse(int btn, int state, int x, int y){

	nextDown = false; prevDown = false;

	y = wh - y;
	if(btn == GLUT_LEFT_BUTTON && state == GLUT_DOWN){

		LEFTMOUSE_DOWN = true;
		ui->mouseClick(x, y);
	}else{
		LEFTMOUSE_DOWN = false;
	}
}
void mouseAim(int x2, int y2){

	ui->mouseMove( x2, gH - y2);
	//LEFTMOUSE_DOWN &&
	if( (FREECAM_MODE || ORBIT_MODE)){

		glutSetCursor (GLUT_CURSOR_NONE);
			
		static int x1(0), y1(0);
		static int resetCnt(0);

		double dx = (double)x2 - (double)(gW/2.0);
		double dy = (double)y2 - (double)(gH/2.0);

		double theshold = 8;

		if(resetCnt > 1){//100 cycles

			if(dx > 0 && dx > theshold){

				if(ORBIT_MODE)
					camera->orbitX(-2);
				else
					camera->panX(-2);

			}else if (dx < -theshold){

				if(ORBIT_MODE)
					camera->orbitX(2);
				else
					camera->panX(2);
			}

			if(dy < 0  && dy < -theshold){

				if(ORBIT_MODE)
					camera->orbitY(2);
				else
					camera->panY(2);

			}else if (dy > theshold){

				if(ORBIT_MODE)
					camera->orbitY(-2);
				else
					camera->panY(-2);
			}

			glutWarpPointer  ( gW/2.0 , gH/2.0 );
			resetCnt = 0;
		
		}else{
			resetCnt++;
		}
	}else{
		glutSetCursor (GLUT_CURSOR_CROSSHAIR);
	}
}
void specialKeys(int key, int x, int y){

	switch(key){
		case GLUT_KEY_UP:
			camera->truckY(.1);
			break;
		case GLUT_KEY_DOWN:
			camera->truckY(-.1);
			break;
		case GLUT_KEY_LEFT:
			camera->truckX(-.1);
			break;
		case GLUT_KEY_RIGHT:
			camera->truckX(.1);
			break;
		case GLUT_KEY_F1:
			cullback ^= true;
			break;
		case GLUT_KEY_F2:
			wireframe_flag ^= true;
			break;
	}
}

void myKeyboard(unsigned char key, int x, int y){

	if(key == ESC) quit = true;

	tolower(key);
	switch(key){
	
		case 'i':
			toggleFreeCamMode();
			break;
		case 'o':
			toggleOrbitCamMode();
			break;
		case 'a':
			camera->panX(5.);
			break;
		case 'd':
			camera->panX(-5.);
			break;
		case 'r':
			camera->panY(5.);
			break;
		case 'f':
			camera->panY(-5.);
			break;
		case 's':
			camera->dolly(-.1);
			break;
		case 'w':
			camera->dolly(.1);
			break;
		case 'q':
			camera->roll(2.);
			break;
		case 'e':
			camera->roll(-2.0);
			break;
		case 't':
			camera->dollyTarget(.1);
			break;
		case 'g':
			camera->dollyTarget(-.1);
			break;
		case 'y':
			camera->dollyCamera(.1);
			break;
		case 'h':
			camera->dollyCamera(-.1);
			break;
		case '[':
			camera->orbitX(-2.);
			break;
		case ']':
			camera->orbitX(2.);
			break;
		case 'p':
			camera->orbitY(2.);
			break;
		case ';':
			camera->orbitY(-2.);
			break;
		case 'v':
			camera->fov++;
			break;
		case 'b':
			camera->fov--;
			break;
		default:
			break;
	}
}

void drawBone(vec3d& p, vec3d& axis, double angle, double length){

	glPushMatrix();
	
	glTranslatef( p[0], p[1], p[2]);
	glRotatef( 180, 0.f, 0.f, 1.f);
	glScalef( 0.5f, length, 0.5f);

	double minY = 0.0f;
	double maxY = 1.0f;
	double minX = 0.0f;
	double maxX = 1.0f;
	double minZ = 0.0f;
	double maxZ = 1.0f;
	double plane = (maxY - minY) / 4.0f;
	double cX = (maxX - minX) / 2.0f;
	double cY = (maxY - minY) / 2.0f;
	double cZ = (maxZ - minZ) / 2.0f;

	glBegin(GL_POLYGON);
		glColor4f(1.f, .5f, 0.5f, .5f);
		
		glVertex3f( minX, plane, maxZ);
		glVertex3f( minX, plane, minZ);

		glVertex3f( cX, maxY, cZ);
	glEnd();
	glBegin(GL_POLYGON);
		glColor4f(.5f, .5f, 1.f, .5f);
		
		glVertex3f( maxX, plane, maxZ);
		glVertex3f( minX, plane, maxZ);

		glVertex3f( cX, maxY, cZ);
	glEnd();
	glBegin(GL_POLYGON);
		glColor4f(.5f, 1.f, 1.f, .5f);
		
		glVertex3f( maxX, plane, minZ);
		glVertex3f( maxX, plane, maxZ);

		glVertex3f( cX, maxY, cZ);
	glEnd();
	glBegin(GL_POLYGON);
		glColor4f(.5f, 1.f, 0.5f, .5f);
		
		glVertex3f( minX, plane, minZ);
		glVertex3f( maxX, plane, minZ);

		glVertex3f( cX, maxY, cZ);
	glEnd();
	/////////////
	glBegin(GL_POLYGON);
		glColor4f(.5f, .5f, .5f, 1.f);
		glVertex3f( minX, plane, minZ);
		glVertex3f( maxX, plane, minZ);
		glVertex3f( maxX, plane, maxZ);
		glVertex3f( minX, plane, maxZ);
	glEnd();

	/////
	glBegin(GL_POLYGON);
		glColor4f(1.f, .5f, 0.5f, .5f);
		
		glVertex3f( minX, plane, minZ);
		glVertex3f( maxX, plane, minZ);
		glVertex3f( cX, minY, cZ);

	glEnd();
	glBegin(GL_POLYGON);
		glColor4f(.5f, 1.f, 0.5f, .5f);

		glVertex3f( maxX, plane, minZ);
		glVertex3f( maxX, plane, maxZ);
		glVertex3f( cX, minY, cY);
	glEnd();
	glBegin(GL_POLYGON);
		glColor4f(.5f, 1.f, 1.f, .5f);
		
		glVertex3f( maxX, plane, maxZ);
		glVertex3f( minX, plane, maxZ);
		glVertex3f( cX, minY, cY);
	glEnd();
	glBegin(GL_POLYGON);
		glColor4f(.5f, .5f, 1.f, .5f);
		
		glVertex3f( minX, plane, maxZ);
		glVertex3f( minX, plane, minZ);
		glVertex3f( cX, minY, cZ);
	glEnd();

	glPopMatrix();
	
}

void updateRot(NODE* n, double theta, vec3d& ori, vec3d& axis){

	vec3d p(n->pos[0], n->pos[1], n->pos[2]);
	
	p -= ori;

	unsigned rot_base = ( n->DOF == 6 ) ? 3 : 0;//make sure channel offset is right

	for( int i(rot_base); i < rot_base + 3; ++i){

		if( n->channels[i] == "Xrotation"){	
			rotate( theta, axis, n->X);
		}else if( n->channels[i] == "Yrotation"){
			rotate( theta, axis, n->Y);
		}else if( n->channels[i] == "Zrotation"){
			rotate( theta, axis, n->Z);
		}
	}	

	rotate( theta, axis, p);

	for(int k = 0; k < n->noofchildren; ++k){

		updateRot(n->children[k], theta, ori, axis);
	}

	p += ori;
	n->pos[0] = p[0];	n->pos[1] = p[1];	n->pos[2] = p[2];
}

void drawAni(NODE* n, int steps, int frame){

	Quaternion<double> X, Y, Z, P, Xp, Yp, Zp;
	
	vec3d p(n->pos[0], n->pos[1], n->pos[2]);

	for(int i(0); i < (n->noofchildren); ++i){

		NODE* child = n->children[i];
		vec3d p2(child->pos[0], child->pos[1], child->pos[2]);

		unsigned rot_base = ( child->DOF == 6 ) ? 3 : 0;//make sure channel offset is right

		for( int i(rot_base); i < rot_base + 3; ++i){

			if( child->channels[i] == "Xrotation"){
				
				updateRot(child, child->rotationsX[frame], p2, child->X);
			}else if( child->channels[i] == "Yrotation"){

				updateRot(child, child->rotationsY[frame], p2, child->Y);
			}else if( child->channels[i] == "Zrotation"){

				updateRot(child, child->rotationsZ[frame], p2, child->Z);
			}
		}		

		//X
		glBegin(GL_LINES);
			glColor4f(1.f, 0.f, 0.f, 1.f);
			glVertex3f(p2[0], p2[1], p2[2]);
			glVertex3f(p2[0] + child->X[0]*3, p2[1] + child->X[1]*3, p2[2] + child->X[2]*3);
		glEnd();
		//Y
		glBegin(GL_LINES);
			glColor4f(0.f, 1.f, 0.f, .5f);
			glVertex3f(p2[0], p2[1], p2[2]);
			glVertex3f(p2[0] + child->Y[0]*3, p2[1] + child->Y[1]*3, p2[2] + child->Y[2]*3);
		glEnd();
		
		//Z
		glBegin(GL_LINES);
			glColor4f(0.f, 0.f, 1.f, .5f);
			glVertex3f(p2[0], p2[1], p2[2]);
			glVertex3f( p2[0] + child->Z[0]*3, p2[1] + child->Z[1]*3, p2[2] + child->Z[2]*3);
		glEnd();
		

		child->pos[0] = p2[0];	child->pos[1] = p2[1];	child->pos[2] = p2[2];

		//////////////////////////////////////////////////////////////////////////////////

		vec3d bone(0.0f, 1.0f, 0.0f);
		vec3d w = (p - p2);

		bone *= w.magnitude();
		vec3d c = (bone^w).normalize();
		
		double theta = acos( (bone*w) / (bone.magnitude() * w.magnitude()) )  * (180.f/3.14159f);

		//drawBone(p, c, theta, bone.magnitude());

		glBegin(GL_LINES);
			glColor4f(0.3f, 0.3f, 0.3f, 1.f);
			glVertex3f(p[0], p[1], p[2]);
			glVertex3f(p2[0], p2[1], p2[2]);
		glEnd();
		/*
		glPointSize(5);
		glBegin(GL_POINTS);
			glColor3f(0., 1., 0.);
			glVertex3f(p[0], p[1], p[2]);
		glEnd();

		glPointSize(5);
		glBegin(GL_POINTS);
			glColor4f(0.f, 0.f, 1.f, .5f);
			glVertex3f(p2[0], p2[1], p2[2]);
		glEnd();*/
		/*
		vec3d tmp;
		for(int i = 0; i<frame; i++)
		{
			tmp = child->history[i];
			glPointSize(5);
			glBegin(GL_POINTS);
				glColor4f(0.5f, 0.f, 1.f, .5f);
				glVertex3f(tmp[0], tmp[1], tmp[2]);
			glEnd();
		}

		child->history[frame] = p2;*/
		drawAni(child, steps - 1, frame);
	}
}

void computeNewPosition(NODE* n, int frame, const vec3d& T, const Quaternion<double>& Q){

	for(int i(0); i < (n->noofchildren); ++i){

		NODE* child = n->children[i];

		//Quaternion<double> X( n->rotationsX[frame], vec3d( 1.0, 0.0, 0.0) );
		//Quaternion<double> Y( n->rotationsY[frame], vec3d( 0.0, 1.0, 0.0) );
		//Quaternion<double> Z( n->rotationsZ[frame], vec3d( 0.0, 0.0, 1.0) );

		Quaternion<double> X( n->rotationsX[frame], vec3d( 1.0, 0.0, 0.0) );
		Quaternion<double> Y( n->rotationsY[frame], vec3d( 0.0, 1.0, 0.0) );
		Quaternion<double> Z( n->rotationsZ[frame], vec3d( 0.0, 0.0, 1.0) );

		vec3d p( child->offset[0], child->offset[1], child->offset[2] );

		Quaternion<double> R = Z*X*Y*Q;
		
		unsigned rot_base = ( n->DOF == 6 ) ? 3 : 0;//make sure channel offset is right

		/*
		for( int i(rot_base); i < rot_base + 3; ++i){

			if( n->channels[i] == "Xrotation"){
				R = X*Q;
			}else if( n->channels[i] == "Yrotation"){
				R = Y*Q;
			}else if( n->channels[i] == "Zrotation"){
				R = Z*Q;
			}
		}*/

		rotate( R, p);
		rotate( R, n->X);
		rotate( R, n->Y);
		rotate( R, n->Z);

		p += T;
		child->pos[0] = p[0];	child->pos[1] = p[1]; child->pos[2] = p[2]; 
	
		computeNewPosition( child, frame, p, R);
	}
}

void drawFigure( NODE* n ){

	for ( int i(0); i <  (n->noofchildren); ++i){

		NODE* child = n->children[i];

		//X
		glBegin(GL_LINES);
			glColor4f(1.f, 0.f, 0.f, 1.f);
			glVertex3f( n->pos[0], n->pos[1], n->pos[2] );
			glVertex3f( n->pos[0] + child->X[0]*3, n->pos[1] + child->X[1]*3, n->pos[2] + child->X[2]*3);
		glEnd();
		//Y
		glBegin(GL_LINES);
			glColor4f(0.f, 1.f, 0.f, .5f);
			glVertex3f( n->pos[0], n->pos[1], n->pos[2] );
			glVertex3f( n->pos[0] + child->Y[0]*3, n->pos[1] + child->Y[1]*3, n->pos[2] + child->Y[2]*3);
		glEnd();
		
		//Z
		glBegin(GL_LINES);
			glColor4f(0.f, 0.f, 1.f, .5f);
			glVertex3f( n->pos[0], n->pos[1], n->pos[2] );
			glVertex3f( n->pos[0] + child->Z[0]*3, n->pos[1] + child->Z[1]*3, n->pos[2] + child->Z[2]*3);
		glEnd();
		/*
		glPointSize(5);
		glBegin(GL_POINTS);
			glColor4f(0.0f, 1.0f, 0.0f, 1.f);
			glVertex3f(n->pos[0], n->pos[1], n->pos[2]);
			glColor4f(0.0f, 0.0f, 1.0f, 1.f);
			glVertex3f( child->pos[0], child->pos[1], child->pos[2]);
		glEnd();*/

		glBegin(GL_LINES);
			glColor4f(0.3f, 0.3f, 0.3f, 1.f);
			glVertex3f( n->pos[0], n->pos[1], n->pos[2]);
			glVertex3f( child->pos[0], child->pos[1], child->pos[2]);
		glEnd();

		drawFigure( child );
	}
}

void computePos(NODE* n, double p[], double& lowestY){

	n->X[0] = 1.f;	n->X[1] = 0.f;	n->X[2] = 0.f;
	n->Y[0] = 0.f;	n->Y[1] = 1.f;	n->Y[2] = 0.f;
	n->Z[0] = 0.f;	n->Z[1] = 0.f;	n->Z[2] = 1.f;

	n->pos[0] = p[0] + n->offset[0];	n->pos[1] = p[1] + n->offset[1];	n->pos[2] = p[2] + n->offset[2];

	if(n->pos[1] < lowestY) {lowestY = n->pos[1];}

	for(int i(0); i < (n->noofchildren); ++i){
		computePos(n->children[i], n->pos, lowestY);
	}
}

void resetPos(NODE* n){

	n->X[0] = 1.f;	n->X[1] = 0.f;	n->X[2] = 0.f;
	n->Y[0] = 0.f;	n->Y[1] = 1.f;	n->Y[2] = 0.f;
	n->Z[0] = 0.f;	n->Z[1] = 0.f;	n->Z[2] = 1.f;

	n->pos[0] = 0;	
	n->pos[1] = 0;	
	n->pos[2] = 0;

	for(int i(0); i < (n->noofchildren); ++i){
		resetPos(n->children[i]);
	}
}

void update(int value) {

	passed_time += TIMER_MS;
	
	if(quit){
		return;
	}else{
		glutTimerFunc(TIMER_MS, update, 0);
	}

	PerspectiveSet(gW, gH, camera->fov);

	glEnable(GL_FOG);
	GLfloat fogColor[] = {0.f, 0.f, 0.f, 1};
    glFogfv(GL_FOG_COLOR, fogColor);
    glFogi(GL_FOG_MODE, GL_LINEAR);
    glFogf(GL_FOG_START, 0.0f);
    glFogf(GL_FOG_END, draw_dist);

	//if(cullback) glCullFace(GL_BACK);
	//else		 glCullFace(GL_FRONT);

	if(wireframe_flag)					glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	else								glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

	glClearColor(fogColor[0], fogColor[1], fogColor[2], fogColor[3]);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	/*if(play){
		//passed_time += TIMER_MS;

		if(frame <  splices[motionIndex][1]){ frame++;}
		else if(frame ==  splices[motionIndex][1]){ 
			if(motionIndex < motionSets.size()-1)
			{
				motionIndex++;
			}else{
				motionIndex = 0;
			}
			
			figure = &motionSets[motionIndex];
			frame = splices[motionIndex][0];
		}else{
			frame = 0;
		}
	}*/

	figure->rootPointY[frame] = 100;

	double lowestY = 40;
	double ori[] = { figure->rootPointX[frame],figure->rootPointY[frame], figure->rootPointZ[frame]};

	//computePos(figure, ori, lowestY);

	figure->frameRate;
	
	if( ORBIT_MODE ){
		camera->at[0] = figure->pos[0] /100.0;
		camera->at[1] = figure->pos[1] /100.0;
		camera->at[2] = figure->pos[2] /100.0;
	}
	

	gluLookAt(camera->pos[0],camera->pos[1],camera->pos[2],
		  camera->at[0],camera->at[1],camera->at[2],
		  camera->up[0],camera->up[1],camera->up[2]);

	//drawCube(camera->at[0], camera->at[1], camera->at[2], 0.1);

	glPushMatrix();
	
	glScalef(.01, .01, .01);

	static double angle = 0.0f;
	angle++;
	if(angle >= 360)	angle = 0;

	if(play){
		//passed_time += TIMER_MS;

		if(frame <  figure->noofFrames - 1){ 
			frame++;
		}else{
			frame = 0;
		}
	}

//frame = 30;
#define OLD 0
#if OLD == 1
	computePos(figure, ori, lowestY);
	vec3d p2(figure->pos[0], figure->pos[1], figure->pos[2]);
	
	unsigned rot_base = ( figure->DOF == 6 ) ? 3 : 0;//make sure channel offset is right
	for( int i(rot_base); i < rot_base + 3; ++i){

		if( figure->channels[i] == "Xrotation"){
				
			updateRot(figure, figure->rotationsX[frame], p2, figure->X);
		}else if( figure->channels[i] == "Yrotation"){

			updateRot(figure, figure->rotationsY[frame], p2, figure->Y);
		}else if( figure->channels[i] == "Zrotation"){

			updateRot(figure, figure->rotationsZ[frame], p2, figure->Z);
		}
	}	

	drawAni(figure, 2, frame);
#else
	resetPos( figure );
	figure->pos[0] = ori[0];	figure->pos[1] = ori[1];	figure->pos[2] = ori[2];
	computeNewPosition( figure, frame, ori, Quaternion<double>( 0, vec3d( 0.0f, 1.0f, 0.0f)) );
	drawFigure( figure );
#endif

	glPopMatrix();

	glBindTexture(GL_TEXTURE_2D, checkerTex.ID);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST) ;
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	glEnable( GL_TEXTURE_2D );
	glNormal3f(0.0,1.0,0.0);
	
	float floor_color[4] = {1.0, 1.0, 1.0,1.0};
	glColor4fv( floor_color);
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, floor_color);

	glBegin(GL_POLYGON);
		
		glTexCoord2f (0.0, 0.0);
		glVertex3f(-30,0,-30);

		glTexCoord2f (0.0, 8.);
		glVertex3f(-30,0, 30);

		glTexCoord2f (8., 8.);
		glVertex3f(30, 0, 30);

		glTexCoord2f (8., 0.0);
		glVertex3f(30, 0, -30);
	glEnd();

	glDisable( GL_TEXTURE_2D );

	draw2DModeON();

	draw2DModeOFF();

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	
	glOrtho(0.0, (GLdouble)gW, 0.0, (GLdouble)gH, .1, draw_dist);
	glViewport(0, 0, gW, gH);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	glDisable(GL_FOG);

	ui->draw();

	glutSwapBuffers();
}

void writeJoint( ostream& outFile, NODE* node){

	outFile << "JOINT " << node->name << "\n{\n" << endl;
	outFile << "OFFSET ";
	
	for(int i = 0; i < 3; ++i){
		outFile << node->offset[i] << " ";
	}
	
	outFile << "CHANNELS ";

	for(int i = 0; i < node->DOF; ++i){
		outFile << node->channels[i] << " ";
	}

	outFile << "\n";

}


void writeBVH( const string& fileName, NODE* figure){

	
}


void main(int argc, char **argv)
{
	//seed the random number generator to give different results each time
	srand(time(0));

	ww = 640;
	wh = 480;

	gW = 640;
	gH = 480;

    glutInit(&argc, argv);

    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB |GLUT_DEPTH);
    glutInitWindowSize(gW, gH);
    glutCreateWindow("Mocap Viewer");

	init2();

	glutMainLoop();
}
