#include <stdio.h> 
#include <string.h> 
#include <math.h> 
#include <iostream>
#include <fstream>
#include <sstream>
#include <boost/algorithm/string.hpp>
#include <vector>
#include "BVHParser.h" 
#include <ctime>

using namespace std;

BVHParser::BVHParser()
{
}

//Add checks for bad files
NODE* BVHParser::getFigure(const char *filename) 
{
	startTime =  time(NULL);
	cout << "Start" << (time(NULL) - startTime) << endl;
	string line;
	ifstream bvhFile (filename);
	
	NODE *root = new NODE;
	NODE *currentNode = root;
	NODE *parent = NULL;

	bool buildingHierarchy = false;
	bool buildingRootNode = false;
	bool buildingJointNode = false;
	bool closingNode = false;

	if (!bvhFile.is_open()){

		cout<<"Error Reading File"<<endl;
		return NULL;
	}


	getline(bvhFile,line);
	unsigned found = line.find("HIERARCHY");

	if(found != string::npos)	//If HIERARCHY we're dealing with a new set of mocap data
	{
		//cout<<"Hierarchy Found"<<endl;
		buildingHierarchy = true;

		found = line.find("ROOT");	//Check if ROOT is in the same line as HIERARCHY
		if(found == string::npos)	//If ROOT does not share the same line as HIERARCHY, get the next line
		{
			getline(bvhFile,line);
		}else{
			buildingRootNode = true;
		}
	}

	while(buildingHierarchy)
	{
		buildingJointNode = (line.find("JOINT") != string::npos);
		closingNode = (line.find("}") != string::npos);

		if(!buildingRootNode)		//if ROOT wasn't found in the same line as HIERARCHY
		{
			buildingRootNode = (line.find("ROOT") != string::npos);
				  
		}else if(buildingJointNode){
			buildingRootNode = false;
		}

		if(buildingJointNode || buildingRootNode)	
		{
			if(buildingRootNode)
			{
				currentNode->parent = NULL;
			}else
			{
				currentNode = new NODE;
				currentNode->parent = parent;
			}
				  
			currentNode->children = NULL;
			currentNode->noofchildren = 0;
			currentNode->length = 0;
			//Set Node's name
			string nodeName = getName(line);
			//cout<<nodeName<<endl;

			currentNode->name = (char*) malloc(strlen(nodeName.c_str()) + 1);
			strcpy(currentNode->name, nodeName.c_str());
			//cout<<currentNode->name<<endl;

			//May be able to assume that next line is curly brace, which means we can get rid of this chunk and replace with getline
			getline(bvhFile,line);
			found = line.find("{");
			if(found != string::npos)
			{
				getline(bvhFile,line);
			}

			//Set offset of node
			found = line.find("OFFSET");
			if(found != string::npos)	
			{
				//cout<<"OFFSET Found"<<endl;
				double* offset = getOffset(line);
				memcpy(currentNode->offset, offset, sizeof currentNode->offset);
				//cout<<currentNode->offset[0]<<endl;			//Debugging check
			}

			//Set degrees of freedom
			getline(bvhFile,line);
			boost::trim(line);
			found = line.find("CHANNELS");
			if(found != string::npos)	
			{

				vector<string> channels;
				getChannels(line, channels);
				currentNode->channels = (string*)malloc(sizeof(string)*channels.size());
				memcpy(currentNode->channels, channels.data(),sizeof(string)*channels.size());
				currentNode->DOF = channels.size();
			}
			//cout<<currentNode->channels[1]<<endl;
			//Checking if we've reached a leaf node

			getline(bvhFile,line);
			boost::trim(line);
			found = line.find("End Site");
			if(found != string::npos)
			{
				getline(bvhFile,line);	//get beginning bracket
				getline(bvhFile,line);	//get offset
				boost::trim(line);

				found = line.find("OFFSET");
				if(found != string::npos)	
				{
					double* endOffset = getOffset(line);
					memcpy(currentNode->endPoint, endOffset, 3*sizeof (double));
					double length = (double)sqrt(pow((endOffset[0]-currentNode->offset[0]), 2.0) +pow((endOffset[1]-currentNode->offset[1]), 2.0)+pow((endOffset[2]-currentNode->offset[2]), 2.0));
					currentNode->length = length;
				}
				getline(bvhFile,line);	//get closing bracket for End Site
				boost::trim(line);

				if(line.find("}") != string::npos)
				{
					buildingJointNode = false;
					buildingRootNode = false;
					closingNode = true;
					getline(bvhFile,line);
					boost::trim(line);
				}
			}else{
				parent = currentNode;
			}

		}else if(closingNode)
		{
			if(parent != NULL)
			{
			addChild(parent, currentNode);
				double length = (double)sqrt(pow((parent->offset[0]-currentNode->offset[0]), 2.0) +pow((parent->offset[1]-currentNode->offset[1]), 2.0)+pow((parent->offset[2]*currentNode->offset[2]), 2.0));
				currentNode->length = length;
			}
			getline(bvhFile,line);
			if(line.find("}") != string::npos)
			{
				currentNode = parent;
				parent = parent->parent;

			}else if(line.find("JOINT") != string::npos)
			{
				closingNode = false;
				buildingJointNode = true;
			}else if(line.find("MOTION") != string::npos)
			{
				buildingHierarchy = false;
			}

		}
	}

	// cout << "Starting Motions: " << (time(NULL) - startTime) << endl;
		  
	while(found == string::npos)		//iterate through file until we find motion
	{
		getline(bvhFile,line);
		boost::trim(line);
		found = line.find("MOTION");
	}

	// cout << "Done Iterating: " << (time(NULL) - startTime) << endl;

	getline(bvhFile,line);
	boost::trim(line);
	if(line.find("Frames") !=string::npos)
	{
		currentNode->noofFrames = getFrames(line);
		initializeDOF(currentNode, currentNode->noofFrames);
		initializeHistory(currentNode, currentNode->noofFrames);
		getline(bvhFile,line);
		boost::trim(line);
	}
	//cout << "Done Finding Frame: " << (time(NULL) - startTime) << endl;

	if(line.find("Frame Time") !=string::npos)
	{
		currentNode->frameRate = getFrameTime(line);
		//getline(bvhFile, line);
	}
	//cout << "Done Finding frame time: " << (time(NULL) - startTime) << endl;

	//cout << "Get Motions: " << (time(NULL) - startTime) << endl;
	int frameCount = 0;

	while( frameCount < currentNode->noofFrames){
		  
		addRotation(currentNode, bvhFile, frameCount);
		bvhFile.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

		frameCount++;
	}
	bvhFile.close();
	//cout << "End: " << (time(NULL) - startTime) << endl;

	return currentNode;
}

string BVHParser::getName( const string& s)
{
	vector <string> nameData;
	boost::split(nameData, s, boost::is_any_of("\t "), boost::token_compress_on);

	while(*nameData.begin() == "")
	{
		nameData.erase(nameData.begin());		//any empty space in vector
	}

	nameData.erase(nameData.begin());		//Removes "JOINT" or "ROOT"
	return nameData[0];
}

void BVHParser::getChannels( const string& s, vector<string>& channelData)
{
	boost::split(channelData,s, boost::is_any_of("\t "), boost::token_compress_on);

	while(*channelData.begin() == "")
	{
		channelData.erase(channelData.begin());		//any empty space in vector
	}

	channelData.erase(channelData.begin());		//Removes "CHANNEL"
	channelData.erase(channelData.begin());		//Removes Dof

	//string* channels = malloc(channelData.size()*sizeof(string)
}

double* BVHParser::getOffset( const string& s)
{
	vector <string> offsetData;
	boost::split(offsetData, s, boost::is_any_of("\t "), boost::token_compress_on);
	
	while(*offsetData.begin() == "")
	{
		offsetData.erase(offsetData.begin());		//any empty space in vector
	}

	offsetData.erase(offsetData.begin());		//Removes "OFFSET"

	double offset[3];						//change to double?  delete later?
	int ctr = 0;
	string tmp;
	for (std::vector<string>::iterator it = offsetData.begin(); it != offsetData.end(); ++it)
	{
		tmp = *it; 
		offset[ctr] = (double) atof(tmp.c_str());
		ctr++;
	}

	return offset;
}

void BVHParser::addChild(NODE* parent, NODE* currentNode)
{
	parent->noofchildren++;
	if(parent->children == NULL)
	{
		parent->children = (NODE**) malloc(sizeof(NODE*));
		//memcpy(parent->children[0], currentNode, sizeof(NODE));	
		parent->children[0] = currentNode;
		
	}else{
		NODE **temp = (NODE**)realloc(parent->children,(parent->noofchildren)*sizeof(NODE*));
		parent->children = temp;
		parent->children[parent->noofchildren-1] = currentNode;

		//cout<<endl<<"Children("<<parent->name<<"):"<<endl;
		for(int i = 0; i<parent->noofchildren; i++)
		{
			//cout<<parent->children[i]->name<<endl;
		}

	}
	
}

double BVHParser::getFrames( const string& s)
{
	vector <string> frameData;
	//boost::split(frameData, s, boost::is_any_of( " /t" ) );
	boost::split(frameData,s, boost::is_any_of("\t "),boost::token_compress_on);
	double frames = 0;

	frameData.erase(frameData.begin());		//Removes "Frame:"

	frames = (double) atof((*frameData.begin()).c_str());
	return frames;
}

double BVHParser::getFrameTime( const string& s)
{
	vector <string> frameTimeData;
	//boost::split(frameTimeData, s, boost::is_any_of( " /t" ) );
	boost::split(frameTimeData,s, boost::is_any_of("\t "),boost::token_compress_on);
	double frameTime = 0;

	frameTimeData.erase(frameTimeData.begin());		//Removes "Frame"
	frameTimeData.erase(frameTimeData.begin());		//Removes "Time:"

	frameTime = (double) atof((*frameTimeData.begin()).c_str());

	return frameTime;
}

void BVHParser::addMotions(const string& s, vector<double>& motions)
{
	vector <string> stringData;
	boost::split(stringData, s, boost::is_any_of( " \t" ) );
	vector<double>::iterator moIt = motions.begin();

	for(std::vector<string>::iterator it = stringData.begin(); it != stringData.end(); ++it)
	{
		if(*it != "")
		{
			(*moIt) = (double)atof((*it).c_str());
			moIt++;
		}
	}
}

void BVHParser::getMotions( const string& s, vector<string>& stringData)
{
	boost::split(stringData, s, boost::is_any_of( " \t" ), boost::token_compress_on);
	while(*stringData.begin() == "")
	{
		stringData.erase(stringData.begin());		//any empty space in the beginning of the vector
	}
}

void BVHParser::initializeDOF(NODE* n, int frames)
{
	if(n->DOF == 6)
	{
		n->rootPointX = new double[frames];
		n->rootPointY = new double[frames];
		n->rootPointZ = new double[frames];
	}

	n->rotationsX = new double[frames];
	n->rotationsY = new double[frames];
	n->rotationsZ = new double[frames];

	if(n->noofchildren > 0)
	{
		for(int i = 0; i < n->noofchildren; i++)
		{
			initializeDOF(n->children[i], frames);	
		}
	}
}

void BVHParser::initializeHistory(NODE* n, int frames)
{
	/*double** hist = (double**)malloc(frames * sizeof(double*));
	for(int i = 0; i < frames; i++){
	  hist[i] = (double*)malloc(3*sizeof(double));
	}*/
	vec3d* hist = (vec3d*)malloc(frames*sizeof(vec3d));
	n->history = hist;
	for(int i = 0; i<n->noofchildren; i++)
	{
		initializeHistory(n->children[i], frames);
	}
}

void BVHParser::addRotation(NODE* n, ifstream& file, int frame){

	if(n->DOF == 6)
	{
		file >> n->rootPointY[frame];
		file >> n->rootPointX[frame];
		file >> n->rootPointZ[frame];

		file >> n->rotationsZ[frame];
		file >> n->rotationsX[frame];
		file >> n->rotationsY[frame];
		
	}else if(n->DOF == 3)
	{
		file >> n->rotationsZ[frame];
		file >> n->rotationsX[frame];
		file >> n->rotationsY[frame];
	}

	for(int i = 0; i < n->noofchildren; i++)
	{
		addRotation(n->children[i], file, frame);	
	}
}

BVHParser::~BVHParser()
{
}